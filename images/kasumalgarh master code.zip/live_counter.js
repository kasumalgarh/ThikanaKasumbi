// --- FIREBASE SETUP ---
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getDatabase, ref, set, onValue, onDisconnect, remove } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

// 👇 आपकी असली Keys यहाँ डाल दी गई हैं (स्क्रीनशॉट से)
const firebaseConfig = {
    apiKey: "AIzaSyDJCSdLfT2VnVVt-xPYPHCj8YZNFrYoUIQ",
    authDomain: "kasumalgarh-live.firebaseapp.com",
    databaseURL: "https://kasumalgarh-live-default-rtdb.firebaseio.com",
    projectId: "kasumalgarh-live",
    storageBucket: "kasumalgarh-live.firebasestorage.app",
    messagingSenderId: "499782037300",
    appId: "1:499782037300:web:957745a5510125ce8cbf61",
    measurementId: "G-87CX7P9WL3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// --- USER TRACKING LOGIC ---
// 1. यूजर को एक रैंडम ID दो
const userId = 'visitor_' + Math.random().toString(36).substr(2, 9);
const currentPage = window.location.pathname.split("/").pop() || "Home"; // पेज का नाम निकालो

// 2. जब यूजर आए, तो Database में एंट्री करो
const userRef = ref(db, 'online_users/' + userId);
set(userRef, {
    page: currentPage,
    device: /Mobi|Android/i.test(navigator.userAgent) ? "Mobile" : "PC", // डिवाइस भी पता चलेगा
    time: Date.now()
});

// 3. जब यूजर वेबसाइट बंद करे, तो उसे हटा दो (Auto Remove)
onDisconnect(userRef).remove();

// --- LIVE PANEL UI (दिखने वाला बॉक्स) ---
const panel = document.createElement('div');
// स्टाइलिंग: यह बॉक्स नीचे बायीं तरफ दिखेगा
panel.style.cssText = "position:fixed; bottom:10px; left:10px; background:rgba(0,0,0,0.85); color:#fcf6ba; border:1px solid #b38728; padding:12px; font-family:'Courier New', monospace; font-size:12px; z-index:9999; border-radius:8px; box-shadow: 0 0 10px rgba(179, 135, 40, 0.3); pointer-events:none; min-width:150px;";
document.body.appendChild(panel);

// 4. डेटाबेस पर नज़र रखो (Live Updates)
const allUsersRef = ref(db, 'online_users');
onValue(allUsersRef, (snapshot) => {
    const users = snapshot.val() || {};
    const total = Object.keys(users).length;
    
    // पेज गिनो
    let pageCounts = {};
    Object.values(users).forEach(u => {
        let p = u.page;
        if(p === "" || p === "kasumalgarh.github.io") p = "Home"; // होम पेज का नाम ठीक करो
        pageCounts[p] = (pageCounts[p] || 0) + 1;
    });

    // पैनल में दिखाओ
    let html = `<div style="text-align:center; border-bottom:1px solid #555; padding-bottom:5px; margin-bottom:5px;">🔴 <b>LIVE: ${total}</b></div>`;
    
    for (let [page, count] of Object.entries(pageCounts)) {
        html += `<div style="display:flex; justify-content:space-between;"><span>${page}:</span> <span style="color:#0f0;">${count}</span></div>`;
    }
    panel.innerHTML = html;
});
