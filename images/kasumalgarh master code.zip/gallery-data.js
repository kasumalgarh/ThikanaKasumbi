const galleryData = [
    {
        "type": "image",
        "category": "other",
        "src": "YGSR.png",
        "caption": "Yuvraj GajRaj Singh ",
        "thumb": ""
    },
    {
        "type": "image",
        "category": "events",
        "src": "3.jpg",
        "caption": "Selected",
        "thumb": ""
    },
    {
        "type": "video",
        "category": "other",
        "src": "https://youtu.be/yEjNE2vHFgg?si=vfxr1At3zqYQMnhg",
        "caption": "Link",
        "thumb": ""
    },
    {
        "type": "video",
        "category": "other",
        "src": "https://youtu.be/8iqfvTHax0s?si=P89q8uSMsL-I2WGw",
        "caption": "Link",
        "thumb": ""
    }
];