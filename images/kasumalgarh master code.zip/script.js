// --- DATA INITIALIZATION ---
let allMembers = [];
let idCounter = 0;

// --- 1. BUILD TREE FUNCTION ---
function buildTree(member) {
    const li = document.createElement('li');
    idCounter++;
    const uniqueID = "node-" + idCounter;
    allMembers.push({ name: member.name, id: uniqueID });

    const span = document.createElement('span');
    span.innerText = member.name;
    span.id = uniqueID;
    
    if(idCounter === 1) { 
        span.classList.add('root-text');
    } else {
        span.classList.add('member-text');
    }

    // ADD SOCIAL ICONS (For GajRaj Singh)
    if(member.name.includes("GajRaj")) {
        let insta = document.createElement('a');
        insta.href = "https://instagram.com/gajsa.kasumbifort"; 
        insta.target = "_blank";
        insta.className = "social-link";
        insta.innerHTML = '<i class="fab fa-instagram"></i>';
        
        let fb = document.createElement('a');
        fb.href = "https://facebook.com/gajsa.kasumbi";
        fb.target = "_blank";
        fb.className = "social-link";
        fb.innerHTML = '<i class="fab fa-facebook-f"></i>';

        span.appendChild(insta);
        span.appendChild(fb);
    }

    li.appendChild(span);

    // --- HOVER TOOLTIP LOGIC ---
    span.addEventListener('mouseenter', function(e) {
        e.stopPropagation();
        
        // 1. Ancestor Path Green Logic
        let current = li;
        while (current) {
            if (current.tagName === 'LI') {
                let nameSpan = current.querySelector('span');
                if(nameSpan) nameSpan.classList.add('highlight-green');
            }
            if(current.parentElement) {
                current = current.parentElement.closest('li');
            } else {
                current = null;
            }
        }

        // 2. SHOW TOOLTIP LOGIC (FIXED POSITION)
        showTooltip(this, li);
    });

    span.addEventListener('mouseleave', function() {
        // Remove Green Path
        document.querySelectorAll('.highlight-green').forEach(el => {
            if(!el.classList.contains('active-click')) {
                el.classList.remove('highlight-green');
            }
        });
        // Hide Tooltip
        document.getElementById('hover-tooltip').style.display = 'none';
    });

    // Click to Open Right Panel
    span.addEventListener('click', function(e) {
            e.stopPropagation();
            handleNameClick(uniqueID, span);
    });

    if (member.children && member.children.length > 0) {
        const ul = document.createElement('ul');
        member.children.forEach(child => {
            ul.appendChild(buildTree(child));
        });
        li.appendChild(ul);
    }
    return li;
}

// TOOLTIP CALCULATION FUNCTION (FIXED)
function showTooltip(spanElement, liElement) {
    let tooltip = document.getElementById('hover-tooltip');
    let name = spanElement.childNodes[0].nodeValue || spanElement.innerText; // Get text only
    
    // A. Find Father
    let fatherName = "Th. Narayan Singh (Founder)";
    let parentLi = liElement.parentElement.closest('li');
    if(parentLi) {
        fatherName = parentLi.querySelector('span').firstChild.textContent;
        fatherName = "Son of <br>" + fatherName;
    } else {
        fatherName = "Founder";
    }

    // B. Find Siblings
    let siblingsCount = 0;
    let parentUl = liElement.parentElement;
    if(parentUl && parentUl.tagName === 'UL') {
        siblingsCount = parentUl.querySelectorAll(':scope > li').length - 1;
    }
    let siblingText = siblingsCount > 0 ? `He has ${siblingsCount} more sibling(s).` : "He is the only child.";

    // C. Find Generation
    let depth = 1;
    let temp = liElement;
    while(temp.parentElement.closest('li')) {
        depth++;
        temp = temp.parentElement.closest('li');
    }
    let suffix = (depth==1)?'st':(depth==2)?'nd':(depth==3)?'rd':'th';
    let genText = `${depth}${suffix} Gen. of Th. Narayan Singh`;

    // HTML
    tooltip.innerHTML = `
        <strong>${name}</strong>
        ${fatherName} <br>
        ${siblingText} <br>
        <span style="color:#ddd; font-size:11px;">${genText}</span>
    `;

    // Position (Fixed logic based on Viewport)
    tooltip.style.display = 'block';
    let rect = spanElement.getBoundingClientRect();
    
    // Set Left
    tooltip.style.left = rect.left + 'px';
    
    // Set Top (Below element)
    let topPos = rect.bottom + 10;
    
    // Check if tooltip goes off bottom of screen
    if (topPos + tooltip.offsetHeight > window.innerHeight) {
            topPos = rect.top - tooltip.offsetHeight - 10; // Show above
    }
    tooltip.style.top = topPos + 'px';
}

// --- INIT TREE ---
const root = document.getElementById('tree-root');
const mainUl = document.createElement('ul');
// Note: familyData comes from family-data.js
mainUl.appendChild(buildTree(familyData)); 
root.appendChild(mainUl);

// --- INDEX LOGIC ---
const indexList = document.getElementById('index-list');
document.getElementById('total-count').innerText = "Total Members: " + allMembers.length;
allMembers.sort((a, b) => a.name.localeCompare(b.name));

function renderIndex(listData) {
    indexList.innerHTML = "";
    listData.forEach(item => {
        let li = document.createElement('li');
        let a = document.createElement('a');
        a.innerText = item.name;
        a.onclick = function(e) {
            e.stopPropagation(); 
            toggleLeftPanel(); 
            handleNameClick(item.id, null); 
        };
        li.appendChild(a);
        indexList.appendChild(li);
    });
}
renderIndex(allMembers);

// --- SIDEBAR TOGGLES ---
function toggleLeftPanel() {
    document.getElementById('left-panel').classList.toggle('open');
    document.getElementById('right-panel').classList.remove('open');
}

function closeRightPanel() {
    document.getElementById('right-panel').classList.remove('open');
    clearHighlights();
}

// --- MODAL LOGIC ---
function openContactModal() {
    document.getElementById('contactModal').style.display = 'flex';
}
function closeContactModal() {
    document.getElementById('contactModal').style.display = 'none';
}

// --- EMAIL SENDING FUNCTION (FIXED ID: service_vdnox8p) ---
function sendEmail() {
    let name = document.getElementById('req-name').value;
    let msg = document.getElementById('req-msg').value;
    
    // अगर खाली है तो रोकें
    if(name === "" || msg === "") {
        alert("Hukum, please write your name and message first.");
        return;
    }

    // बटन का टेक्स्ट बदलें
    let btn = document.querySelector(".send-btn");
    let originalText = btn.innerText;
    btn.innerText = "Sending...";
    btn.disabled = true;

    // EmailJS Parameters
    var templateParams = {
        from_name: name,
        message: msg,
        reply_to: "User"
    };

    // ✅ FIXED ID (Lowercase 's')
    emailjs.send('service_vdnox8p', 'template_xx3a4tt', templateParams)
        .then(function(response) {
            console.log('SUCCESS!', response.status, response.text);
            alert("Message sent successfully via Email! We will update it soon.");
            
            // फॉर्म साफ़ करें और बंद करें
            document.getElementById('req-name').value = "";
            document.getElementById('req-msg').value = "";
            closeContactModal();
            
            btn.innerText = originalText;
            btn.disabled = false;
        }, function(error) {
            console.log('FAILED...', error);
            // एरर का कारण जानने के लिए अलर्ट में दिखाएंगे
            alert("Failed to send. Error: " + JSON.stringify(error));
            btn.innerText = originalText;
            btn.disabled = false;
        });
}

// --- SEARCH LOGIC ---
function filterNames() {
    let input = document.getElementById('search-box');
    let clearBtn = document.getElementById('clear-search');
    let val = input.value.toLowerCase();
    
    if(val.length > 0) clearBtn.style.display = 'block';
    else clearBtn.style.display = 'none';

    let filtered = allMembers.filter(member => member.name.toLowerCase().includes(val));
    renderIndex(filtered);
}

function clearSearch() {
    let input = document.getElementById('search-box');
    input.value = "";
    filterNames(); 
}

// --- CLICK & DETAILS LOGIC ---
function handleNameClick(id, indexLinkElement) {
    clearHighlights();
    let targetSpan = document.getElementById(id);
    if(targetSpan) {
        targetSpan.classList.add('highlight-green');
        targetSpan.classList.add('active-click');
        targetSpan.scrollIntoView({behavior: "smooth", block: "center", inline: "center"});
        showRightPanel(targetSpan);
    }
}

function clearHighlights() {
    document.querySelectorAll('.highlight-green').forEach(el => el.classList.remove('highlight-green'));
    document.querySelectorAll('.active-click').forEach(el => el.classList.remove('active-click'));
}

// --- RIGHT PANEL FUNCTION ---
function showRightPanel(targetNode) {
    const panel = document.getElementById('right-panel');
    const headerBox = document.getElementById('panel-header');
    const list = document.getElementById('lineage-content');
    list.innerHTML = ""; 

    let personName = targetNode.childNodes[0].nodeValue || targetNode.innerText;
    let path = [];
    let current = targetNode;
    let generationCount = 0;
    
    while(current) {
        if(current.tagName === 'SPAN') {
            let txt = current.childNodes[0].nodeValue || current.innerText;
            path.unshift(txt); 
            generationCount++;
        }
        let parentLi = current.closest('li').parentElement.closest('li');
        if(parentLi) {
            current = parentLi.querySelector('span');
        } else {
            current = null;
        }
    }

    let fatherName = path.length > 1 ? path[path.length - 2] : "Founder";
    let parentUl = targetNode.closest('li').parentElement;
    let siblingsCount = (parentUl && parentUl.tagName === 'UL') ? parentUl.querySelectorAll(':scope > li').length - 1 : 0;

    let relationText = personName.toLowerCase().includes('baisa') ? "Daughter of" : "Son of";
    if(generationCount === 1) relationText = "Founder";

    let siblingText = siblingsCount === 0 ? "He is the only child." : `He has ${siblingsCount} more sibling(s).`;
    let suffix = (generationCount==1)?'st':(generationCount==2)?'nd':(generationCount==3)?'rd':'th';

    headerBox.innerHTML = `
        <h2 class="lineage-title-name">${personName}</h2>
        <div class="lineage-details">
            <div><strong>${relationText}</strong> <br> ${fatherName}</div>
            <hr style="border:0; border-top:1px dashed #ccc; margin:5px 0;">
            <div>${siblingText}</div>
            <div><strong>${generationCount}${suffix} Gen.</strong> of Th. Narayan Singh</div>
        </div>
    `;

    path.forEach(name => {
        let li = document.createElement('li');
        li.className = 'lineage-item';
        li.innerHTML = `<span class="lineage-name">${name}</span>`;
        list.appendChild(li);
    });

    panel.classList.add('open');
    document.getElementById('left-panel').classList.remove('open');
}

// Close panels on outside click
document.addEventListener('click', function(e) {
    if (!e.target.closest('.sidebar-left') && 
        !e.target.closest('.sidebar-right') && 
        !e.target.closest('.nav-btn') &&
        !e.target.closest('.modal-box') &&
        !e.target.classList.contains('member-text')) {
        
        document.getElementById('left-panel').classList.remove('open');
        closeRightPanel();
        closeContactModal();
    }
});

// --- MOBILE MENU LOGIC ---
function toggleMobileMenu() {
    let menu = document.getElementById('mobile-menu-overlay');
    // अगर मेनू खुला है तो बंद करें, बंद है तो खोलें
    if (menu.classList.contains('open')) {
        menu.classList.remove('open');
    } else {
        menu.classList.add('open');
    }
}

// बाहर क्लिक करने पर बंद करने का कोड
document.addEventListener('click', function(event) {
    let menu = document.getElementById('mobile-menu-overlay');
    let hamburger = document.querySelector('.hamburger-icon');

    // अगर क्लिक मेनू या बटन के बाहर हुआ, तो मेनू बंद कर दें
    if (menu && menu.classList.contains('open')) {
        if (!menu.contains(event.target) && !hamburger.contains(event.target)) {
            menu.classList.remove('open');
        }
    }
});
