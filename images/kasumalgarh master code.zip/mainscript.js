// =========================================
// 1. PRELOADER LOGIC (Common)
// =========================================
window.addEventListener("load", function() {
    const loader = document.getElementById("preloader");
    if (loader) {
        setTimeout(() => {
            loader.style.opacity = "0";
            setTimeout(() => {
                loader.style.display = "none";
            }, 800);
        }, 3000); 
    }
});

// =========================================
// 2. MENU LOGIC (Common)
// =========================================
function toggleMenu() {
    const menu = document.getElementById("nav-menu");
    const btn = document.getElementById("mobile-menu-btn");
    menu.classList.toggle("active");
    
    if (menu.classList.contains("active")) {
        btn.innerHTML = "×"; // Close icon
        btn.style.fontSize = "30px";
    } else {
        btn.innerHTML = "☰"; // Hamburger icon
        btn.style.fontSize = "25px";
    }
}

// Close menu when clicking outside
document.addEventListener('click', function(event) {
    const menu = document.getElementById("nav-menu");
    const btn = document.getElementById("mobile-menu-btn");
    
    // Check if elements exist before checking contains
    if (menu && btn) {
        if (!menu.contains(event.target) && !btn.contains(event.target)) {
            if (menu.classList.contains("active")) {
                menu.classList.remove("active");
                btn.innerHTML = "☰";
            }
        }
    }
});

// =========================================
// 3. SLIDER LOGIC (Home Page Only)
// =========================================
const heroSection = document.getElementById('hero-slider');

if (heroSection) {
    const images = [
        '1.png',
        '2.jpg',
        '4.jpg', 
        '3.jpg'
    ];
    
    // Preload images
    images.forEach((img) => {
        const i = new Image();
        i.src = img;
    });

    let currentIndex = 0;

    function changeBackgroundImage() {
        currentIndex++;
        if (currentIndex >= images.length) {
            currentIndex = 0;
        }
        heroSection.style.backgroundImage = `linear-gradient(rgba(0, 0, 51, 0.6), rgba(0, 0, 51, 0.9)), url('${images[currentIndex]}')`;
    }

    setInterval(changeBackgroundImage, 3000);
}

// =========================================
// 4. LIKE BUTTON LOGIC (History Page Only)
// =========================================
const likeBtn = document.getElementById('likeBtn');

if (likeBtn) {
    let likeCount = 124; // Starting count
    const hasLiked = localStorage.getItem('kasumbi_liked') === 'true';
    const likeIcon = document.getElementById('likeIcon');
    const likeText = document.getElementById('likeText');
    const likeCountSpan = document.getElementById('likeCount');
    
    if (hasLiked) {
        likeBtn.classList.add('liked');
        likeIcon.classList.remove('fa-regular');
        likeIcon.classList.add('fa-solid');
        likeText.innerText = "Liked";
        likeCount++;
    }
    likeCountSpan.innerText = likeCount;

    // Make function global so HTML onclick works
    window.toggleLike = function() {
        if (likeBtn.classList.contains('liked')) {
            likeBtn.classList.remove('liked');
            likeIcon.classList.remove('fa-solid');
            likeIcon.classList.add('fa-regular');
            likeText.innerText = "Like";
            likeCount--;
            localStorage.setItem('kasumbi_liked', 'false');
        } else {
            likeBtn.classList.add('liked');
            likeIcon.classList.remove('fa-regular');
            likeIcon.classList.add('fa-solid');
            likeText.innerText = "Liked";
            likeCount++;
            localStorage.setItem('kasumbi_liked', 'true');
        }
        likeCountSpan.innerText = likeCount;
    }
}

// =========================================
// 5. SHARE FUNCTION (Common)
// =========================================
window.shareWebsite = function() {
    if (navigator.share) {
        navigator.share({
            title: 'KASUMALGARH',
            text: 'Explore the royal heritage of Fort Kasumbi.',
            url: window.location.href,
        }).catch((error) => console.log('Error sharing', error));
    } else {
        navigator.clipboard.writeText(window.location.href);
        alert("Link copied to clipboard!");
    }
}
// =========================================
// GALLERY LIGHTBOX LOGIC (Paste at bottom of mainscript.js)
// =========================================

window.openLightbox = function(imgSrc) {
    const lightbox = document.getElementById("lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    if (lightbox && lightboxImg) {
        lightbox.style.display = "block";
        lightboxImg.src = imgSrc;
    }
}

window.closeLightbox = function() {
    const lightbox = document.getElementById("lightbox");
    if (lightbox) {
        lightbox.style.display = "none";
    }
}
// =========================================
// 🎵 ROYAL MUSIC PLAYER LOGIC
// =========================================
const music = document.getElementById("bg-music");
const musicBtn = document.getElementById("music-btn");
const musicText = document.getElementById("music-text");
let isPlaying = false;

function toggleMusic() {
    if (isPlaying) {
        music.pause();
        musicBtn.classList.remove("playing");
        musicBtn.innerHTML = '<i class="fa-solid fa-music"></i> <span id="music-text">Play Royal Tune</span>';
        isPlaying = false;
    } else {
        music.play().then(() => {
            musicBtn.classList.add("playing");
            musicBtn.innerHTML = '<i class="fa-solid fa-volume-high"></i> <span id="music-text">Pause Music</span>';
            isPlaying = true;
        }).catch(error => {
            console.log("Audio play failed (User interaction required):", error);
        });
    }
}

// Optional: Try to play automatically (Browsers might block this)
// window.addEventListener('click', () => { if(!isPlaying) toggleMusic(); }, { once: true });