const familyData = {
    "name": "Raj Shree Thakur Saheb Narayan Singh",
    "children": [
        {
            "name": "Th. Akhe Singh",
            "children": [
                {
                    "name": "Th. Mangal Singh",
                    "children": [
                        {
                            "name": "Th. Bakhtawar Singh",
                            "children": [
                                {
                                    "name": "Th. Raghunath Singh",
                                    "children": [
                                        {
                                            "name": "Th. Roop Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Ridmal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Bhairu Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Th. Mahendra Singh",
                                                                    "children": [
                                                                        {
                                                                            "name": "Yuvraj GajRaj Singh",
                                                                            "children": [
                                                                                {
                                                                                    "name": "Bh Khushvendra Singh",
                                                                                    "title": "",
                                                                                    "children": []
                                                                                }
                                                                            ]
                                                                        },
                                                                        {
                                                                            "name": "Kr. Shivraj Singh",
                                                                            "children": []
                                                                        },
                                                                        {
                                                                            "name": "Baisa Hrishiraj Rathore",
                                                                            "children": []
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Th. Partap Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Th. Rajendra Singh",
                                                                    "children": [
                                                                        {
                                                                            "name": "Kr. Arun Singh",
                                                                            "children": [
                                                                                {
                                                                                    "name": "Bhanwar Baisa Raghvi Rathore",
                                                                                    "children": []
                                                                                }
                                                                            ]
                                                                        },
                                                                        {
                                                                            "name": "Baisa Rajlaxmi Rathore",
                                                                            "children": []
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "name": "Th. Ravindra Singh",
                                                                    "children": [
                                                                        {
                                                                            "name": "Baisa Yogita Rathore",
                                                                            "children": []
                                                                        },
                                                                        {
                                                                            "name": "Baisa Garima Rathore",
                                                                            "children": []
                                                                        },
                                                                        {
                                                                            "name": "Kr. Yashvardhan Singh Rathore",
                                                                            "children": []
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Gopinath Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Sonath Singh",
                                                    "children": []
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "name": "Th. Jawahar Singh",
                            "children": [
                                {
                                    "name": "Th. Sabal Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Balnwant Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Sawant Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Bhiv Singh",
                                    "children": [
                                        {
                                            "name": "Th. Lal Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Richhpal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Bhawani Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. Devendra Singh",
                                                                    "children": [
                                                                        {
                                                                            "name": "Bh. Daksh Rathore",
                                                                            "children": []
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "name": "Kr. Ajeet Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Th. Ratan Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. Vikram Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Kr. Narpat Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Th. Yogendra Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Th. Kuldeep Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Th. Tej Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. Jaydeep Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Bhagirath Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Rajendra Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Manohar Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Anand Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Gajendra Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Keshar Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Sopal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Indra Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Narendra Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Ugam Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Baagh Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Laxman Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Narpat Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Partap Singh",
                                                    "children": []
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Bane Singh",
                                            "children": []
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    "name": "Th. Bhairu Singh",
                    "children": [
                        {
                            "name": "Th. Laxman Singh",
                            "children": []
                        },
                        {
                            "name": "Th. Bhopal Singh",
                            "children": [
                                {
                                    "name": "Th. Aman Singh",
                                    "children": [
                                        {
                                            "name": "Th. Hari Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Bhanwar Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Bhagirath Singh",
                                                    "children": []
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Sujan Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Nawal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Ranveer Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Sumer Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. Sudhir Partap Singh",
                                                                    "children": [
                                                                        {
                                                                            "name": "Bh. Anirudh Partap Singh",
                                                                            "children": []
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "name": "Kr. Himmt Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Kr. Kishan Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Th. Girdhari Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. Aaditya Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Khuman Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Banne Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Ugam Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Kan Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Sawant Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Mahaveer Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Nitendra Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Hem Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Achal Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Ram Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Moti Singh",
                                                    "children": []
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "name": "Th. Balwant Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Bakshiram Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Chatar Singh",
                                    "children": [
                                        {
                                            "name": "Th. Ganesh Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Bhanwar Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Gajendra Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Bh. Tanmay Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Mohan Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Bajrang Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Bh. Rudrapartap Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Dungar Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Ajeet Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Tool Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Rawant Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Govind Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. Harshvardhan Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Kr. Yashvardhan Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Th. Mahendra Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Kr. SuryaVardhan Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Kishor Singh",
                                            "children": [
                                                {
                                                    "name": "Kr. Karan Singh",
                                                    "children": [
                                                        {
                                                            "name": "Bh. Jitendra Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Kr. Rajveer Singh",
                                                    "children": [
                                                        {
                                                            "name": "Bh. Aryan Rathore",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    "name": "Th. Ranjit Singh",
                    "children": [
                        {
                            "name": "Th. Bachan Singh",
                            "children": [
                                {
                                    "name": "Th. Ganga Singh",
                                    "children": [
                                        {
                                            "name": "Th. Sardar Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Selab Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Bhoor Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Dhukal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Madan Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Chhagan Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Bhagirath Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Th. Norang Singh",
                                                                    "children": [
                                                                        {
                                                                            "name": "Kr. Govind Singh",
                                                                            "children": []
                                                                        },
                                                                        {
                                                                            "name": "Kr. Manvendra Singh",
                                                                            "children": []
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Th. Laxman Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Manohar Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Bhanwar Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Hukam Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Megh Singh",
                                                    "children": []
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Ajeet Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Sarup Singh",
                                            "children": []
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "name": "Th. Om Singh",
                            "children": [
                                {
                                    "name": "Th. Ganga Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Dhan Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Sujan Singh",
                                    "children": [
                                        {
                                            "name": "Th. Rawat Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Dhir Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Fool Singh",
                                            "children": [
                                                {
                                                    "name": "Kr. Raghuveer Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Mahipal Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Sarwan Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Hari Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        {
            "name": "Th. Sangram Singh",
            "children": []
        },
        {
            "name": "Th. Surat Singh",
            "children": [
                {
                    "name": "Th. Hanwant Singh",
                    "children": [
                        {
                            "name": "Th. Jagat Singh",
                            "children": [
                                {
                                    "name": "Th. Baldev Singh",
                                    "children": [
                                        {
                                            "name": "Th. Sadul Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Guman Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Mool Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Dool Singh",
                                                    "children": []
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Devi Singh",
                                            "children": []
                                        }
                                    ]
                                },
                                {
                                    "name": "Th. Kushal Singh",
                                    "children": []
                                },
                                {
                                    "name": "Th. Gangabaks Singh",
                                    "children": [
                                        {
                                            "name": "Th. Daal Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Fate Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Bhanwar Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Bh. Yashpal Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Bh. Shakti Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Kr. Mahendra Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Bh. Vijaypal Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Bh. Ajaypal Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Kr. Girwar Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Bh. Narendra Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Bh. Gopal Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            "name": "Kr. Bhawani Singh",
                                                            "children": [
                                                                {
                                                                    "name": "Bh. Shivraj Singh",
                                                                    "children": []
                                                                },
                                                                {
                                                                    "name": "Bh. Jivraj Singh",
                                                                    "children": []
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Nathu Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Bhagwan Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Bajrang Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Prithvi Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Vikram Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Ganpat Singh",
                                            "children": []
                                        },
                                        {
                                            "name": "Th. Sodan Singh",
                                            "children": []
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "name": "Th. Hamir Singh",
                            "children": [
                                {
                                    "name": "Th. Pem Singh",
                                    "children": [
                                        {
                                            "name": "Th. Govind Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Jagmal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Th. Mangu Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Th. Partap Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Sopal Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Raghuveer Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Bhagwan Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                },
                                                {
                                                    "name": "Th. Ugam Singh",
                                                    "children": [
                                                        {
                                                            "name": "Kr. Manmohan Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Man Singh",
                                                            "children": []
                                                        },
                                                        {
                                                            "name": "Kr. Kan Singh",
                                                            "children": []
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "name": "Th. Jet Singh",
                                            "children": [
                                                {
                                                    "name": "Th. Sawai Singh",
                                                    "children": []
                                                },
                                                {
                                                    "name": "Th. Ranveer Singh",
                                                    "children": []
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "name": "Th. Metab Singh",
                            "children": []
                        },
                        {
                            "name": "Th. Shal Singh",
                            "children": []
                        },
                        {
                            "name": "Th. Onad Singh",
                            "children": []
                        }
                    ]
                },
                {
                    "name": "Th. Bagh Singh",
                    "children": []
                }
            ]
        },
        {
            "name": "Th. Sardar Singh",
            "children": []
        }
    ]
};